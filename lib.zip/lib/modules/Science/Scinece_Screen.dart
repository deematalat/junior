import 'package:flutter/cupertino.dart';

class Science_Screen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child:  Text("Science",
          style:TextStyle(
            fontWeight: FontWeight.bold,
            fontSize:25.0,
          )),
      );

  }
}
