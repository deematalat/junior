import 'package:flutter/cupertino.dart';

class articalView extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
