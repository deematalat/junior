import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:path/path.dart';
import 'package:untitled/layouts/todoapp/cubit_cubit.dart';

import '../../shared/components/components.dart';
import '../../shared/components/constants.dart';

class NewTasksScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
  return  BlocConsumer<AppCubit,AppState>(builder: (Context,State ){
   var tasks= AppCubit().tasks;
   return ListView.separated(
       itemBuilder: (context,index)=>bulidItemTasks(tasks[index]),
       separatorBuilder:(context,index)=>Container(
         width:double.infinity,
         height: 1.0,
         color: Colors.grey,
       ),
       itemCount: tasks.length
   );
  }, listener: (Context,State){}

  );
  }
}
