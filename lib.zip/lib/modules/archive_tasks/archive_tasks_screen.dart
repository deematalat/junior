

import 'package:flutter/material.dart';

class  ArchiveTasksScreen extends StatelessWidget {
  const  ArchiveTasksScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "archive tasks",
        style:TextStyle(
          fontWeight:FontWeight.bold,
          fontSize:25.0
        ),
      ),
    );
  }
}
