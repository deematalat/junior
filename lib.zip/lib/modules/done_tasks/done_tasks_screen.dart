

import 'package:flutter/material.dart';

class DoneTasksScreen extends StatelessWidget {
  const DoneTasksScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        "done tasks",
        style:TextStyle(
          fontWeight:FontWeight.bold,
          fontSize:25.0
        ),
      ),
    );
  }
}
