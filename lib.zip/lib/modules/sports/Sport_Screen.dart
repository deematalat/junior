import 'package:flutter/cupertino.dart';

class Sport_Screen  extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child:  Text("Sport",
      style:TextStyle(
        fontWeight: FontWeight.bold,
        fontSize:25.0,
      )),
    );
  }
}
