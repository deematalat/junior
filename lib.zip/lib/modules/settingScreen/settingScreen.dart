import 'package:flutter/cupertino.dart';

class SettingScreen extends StatelessWidget {  @override
  Widget build(BuildContext context) {
    return Center(
      child:  Text("Settings",
          style:TextStyle(
            fontWeight: FontWeight.bold,
            fontSize:25.0,
          )),
    );
  }
}


