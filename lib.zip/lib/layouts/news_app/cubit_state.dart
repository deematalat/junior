part of 'cubit_cubit.dart';

@immutable
abstract class  state {}
class  Initial extends  state {}
class NewsBottomNafState extends state{}

